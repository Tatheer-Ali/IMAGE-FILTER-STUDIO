#include "Admin.h"
#include "CatalogManager.h"
#include "CustomerManager.h"
#include "SessionManager.h"
#include <iostream>
using namespace std;

const string Admin::ADMIN_CNIC = "0000000000000";
const string Admin::ADMIN_PASSWORD = "Admin1234";

Admin::Admin() : User(ADMIN_CNIC, "Administrator") {
}
Admin::~Admin() {
}

bool Admin::checkCredentials(const string& cnic, const string& password) {
if (cnic == ADMIN_CNIC && password == ADMIN_PASSWORD){
return 1;
}
return 0;
}

void Admin::showMenu() {
    int choice;
    do {
        cout << endl << " +----------------------------------------+";
        cout << endl << "||   ADMIN PANEL : Image Filter Studio    ||";
        cout << endl << " +----------------------------------------+";
        cout << endl << "||  1. Manage Filter Catalog              ||";
        cout << endl << "||  2. Manage Customers                   ||";
        cout << endl << "||  3. View All Sessions                  ||";
        cout << endl << "||  4. Logout                             ||";
        cout << endl << " +----------------------------------------+";
        cout << endl << "Enter choice: ";
        cin >> choice;
        cin.ignore();
        if (choice == 1 ){
         manageCatalog();
        }
        else if (choice == 2){
          manageCustomers();
        }
        else if (choice == 3){
        viewSessions();
        }
        else if (choice == 4){
        cout << "LOGGING OUT....";
        }
        else{
        cout << "INVALID CHOICE!!!";
        }
        
    } while (choice != 4);
}

void Admin::manageCatalog() {
    CatalogManager::viewCatalog();
    int id;
    cout << "Enter Filter ID to toggle (0 to exit): ";
    cin >> id;
    if (id >= 1 && id <= 10) {
        CatalogManager::toggleFilter(id);
    }
}

void Admin::manageCustomers() {
    int choice;
    do {
        
        cout << endl << " +----------------------------------------+";
        cout << endl << "||  ******* Customer Management *******   ||";
        cout << endl << " +----------------------------------------+";
        cout << endl << "||  1. View All Customers                 ||";
        cout << endl << "||  2. Search Customer                    ||";
        cout << endl << "||  3. Block Customer                     ||";
        cout << endl << "||  4. Delete Customer                    ||";
        cout << endl << "||  5. Back                               ||";
        cout << endl << " +----------------------------------------+";
      
        cout << endl << "Select Choice: ";
        cin >> choice;
        cin.ignore();
         if (choice == 1 ){
         CustomerManager::viewAll();
        }
        else if (choice == 2){
          string term;
                cout << "Enter CNIC or name: ";
                getline(cin, term);
                CustomerManager::search(term);
        }
        else if (choice == 3){
          string cnic;
                cout << "Enter CNIC to block: ";
                getline(cin, cnic);
                CustomerManager::blockCustomer(cnic);
        }
        else if (choice == 4){
       string cnic;
                cout << "Enter CNIC to delete: ";
                getline(cin, cnic);
                CustomerManager::deleteCustomer(cnic);
        }
        else{
        cout << "INVALID CHOICE!!!";
        }
       
           
          
    } while (choice != 5);
}

void Admin::viewSessions() {
    SessionManager::viewAllSessions();
}

string Admin::getRole() const { 
return "Admin"; 
}
