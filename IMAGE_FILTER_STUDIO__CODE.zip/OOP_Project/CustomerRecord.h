#ifndef CUSTOMERRECORD_H
#define CUSTOMERRECORD_H

#include <string>
using namespace std;

struct CustomerRecord {
    string cnic;
    string password;
    string fullName;
    string gender;
    string phone;
    string city;
    int isBlocked;
};

#endif
