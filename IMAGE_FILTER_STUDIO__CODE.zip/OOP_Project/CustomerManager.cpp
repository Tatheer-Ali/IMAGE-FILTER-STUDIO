#include "CustomerManager.h"
#include <fstream>
#include <iostream>
using namespace std;

static bool isDigit(char c) { 
if(c >= '0' && c <= '9')
return 1;

return 0;
}
static bool isUpper(char c) { 
if(c >= 'A' && c <= 'Z'){
return 1;
}
return 0;
}

bool CustomerManager::registerCustomer(const string& cnic, const string& password,const string& fullName, const string& gender,
const string& phone, const string& city) {
    if (cnicExists(cnic)) {
        cout << "CNIC already exists" << endl;
        return false;
    }
    if (isBlocked(cnic)) {
        cout << "CNIC is blocked" << endl;
        return false;
    }
    if (password.length() != 9) {
        cout << "Password must be exactly 9 characters" << endl;
        return false;
    }
    bool checkUpper = false, checkDigit = false;
    for (int i = 0; i < password.length(); i++) {
        char ch = password[i];
        if (isUpper(ch)){ 
        checkUpper = true;
        }
        if (isDigit(ch)){ 
        checkDigit = true;
    }}
    if (!checkUpper || !checkDigit) {
        cout << "Password must contain at least one uppercase and one digit" << endl;
        return false;
    }
    ofstream file("customers.txt", ios::app);
    if (!file){ 
    return false;
    }
    file << cnic << "|" << password << "|" << fullName << "|" << gender << "|" << phone << "|" << city << "|0" <<endl;
    return true;
}

bool CustomerManager::loginCustomer(const string& cnic, const string& password, string& name, bool& isBlocked) {
    vector<CustomerRecord> records = loadAll();
    for (int i = 0; i < records.size(); i++) {
        const CustomerRecord& rec = records[i];
        if (rec.cnic == cnic && rec.password == password) {
            name = rec.fullName;
            isBlocked = (rec.isBlocked == 1);
            return true;
        }
    }
    return false;
}

bool CustomerManager::isBlocked(const string& cnic) {
    ifstream file("blocked_cnics.txt");
    string line;
    while (getline(file, line)) {
        if (line == cnic){ 
        return true;
        }
    }
    return false;
}

vector<CustomerRecord> CustomerManager::loadAll() {
    vector<CustomerRecord> records;
    ifstream file("customers.txt");
    string line;
    while (getline(file, line)) {
        CustomerRecord rec;
        // manual parse without stringstream
        int pos = 0;
        int last = 0;
        // cnic
        while (line[pos] != '|' && line[pos] != '\0') pos++;
        rec.cnic = line.substr(last, pos - last);
        last = ++pos;
        // password
        while (line[pos] != '|' && line[pos] != '\0') pos++;
        rec.password = line.substr(last, pos - last);
        last = ++pos;
        // fullName
        while (line[pos] != '|' && line[pos] != '\0') pos++;
        rec.fullName = line.substr(last, pos - last);
        last = ++pos;
        // gender
        while (line[pos] != '|' && line[pos] != '\0') pos++;
        rec.gender = line.substr(last, pos - last);
        last = ++pos;
        // phone
        while (line[pos] != '|' && line[pos] != '\0') pos++;
        rec.phone = line.substr(last, pos - last);
        last = ++pos;
        // city
        while (line[pos] != '|' && line[pos] != '\0') pos++;
        rec.city = line.substr(last, pos - last);
        last = ++pos;
        // isBlocked
        
        rec.isBlocked = line[pos] - '0';
        records.push_back(rec);
    }
    return records;
}

void CustomerManager::saveAll(const vector<CustomerRecord>& records) {
    ofstream file("customers.txt");
    for (int i = 0; i < records.size();i++) {
        const CustomerRecord& rec = records[i];
        file << rec.cnic << "|" << rec.password << "|" << rec.fullName << "|" << rec.gender << "|" << rec.phone << "|" << rec.city << "|" << rec.isBlocked << endl;
    }
}

void CustomerManager::addToBlocked(const string& cnic) {
    ofstream file("blocked_cnics.txt", ios::app);
    file << cnic << endl;
}

void CustomerManager::viewAll() {
    vector<CustomerRecord> records = loadAll();
    cout << endl << "CNIC          | Name              | Gender | Phone       | City      | Blocked" ;
    cout << endl <<"-------------------------------------------------------------------------------" <<endl;
    for (int i = 0; i < records.size(); ++i) {
        const CustomerRecord& r = records[i];
        cout << r.cnic << " | " << r.fullName << "      | " << r.gender << "   |  "<< r.phone << "  | " << r.city << "  | ";
        if (r.isBlocked){
        cout << "YES" << endl;
        }
        else{
        cout << "NO" << endl;
        }
        
    }
}

void CustomerManager::search(const string& term) {
    vector<CustomerRecord> records = loadAll();
    bool found = false;
    for (int i = 0; i < records.size(); i++) {
        const CustomerRecord& r = records[i];
        if (r.cnic == term || r.fullName.find(term) != string::npos) {
            cout << r.cnic << " | " << r.fullName << " | " << r.gender << " | " << r.phone << " | " << r.city << " | ";
        if (r.isBlocked){
        cout << "Blocked" << endl;
        }
        else{
        cout << "Active" << endl;
        }
            found = true;
        }
    }
    if (!found) cout << "No customer found" << endl;
}

void CustomerManager::blockCustomer(const string& cnic) {
    vector<CustomerRecord> records = loadAll();
    for (int i = 0; i < records.size(); i++) {
        if (records[i].cnic == cnic) {
            if (records[i].isBlocked) {
                cout << "Customer already blocked" <<  endl;
                return;
            }
            records[i].isBlocked = 1;
            saveAll(records);
            addToBlocked(cnic);
            cout << "Customer blocked " << endl;
            return;
        }
    }
    cout << "Customer not found" << endl;
}

void CustomerManager::deleteCustomer(const string& cnic) {
    vector<CustomerRecord> records = loadAll();
    vector<CustomerRecord> newRecords;
    for (int i = 0; i < records.size(); i++) {
        if (records[i].cnic != cnic) 
        newRecords.push_back(records[i]);
    }
    if (newRecords.size() != records.size()) {
        saveAll(newRecords);
        cout << "Customer deleted" << endl;
    } else {
        cout << "Customer not found" << endl;
    }
}

string CustomerManager::getCustomerName(const string& cnic) {
    vector<CustomerRecord> records = loadAll();
    for (int i = 0; i < records.size(); i++) {
        if (records[i].cnic == cnic){ 
        return records[i].fullName;}
    }
    return "";
}

bool CustomerManager::cnicExists(const string& cnic) {
    vector<CustomerRecord> records = loadAll();
    for (int i = 0; i < records.size(); i++) {
        if (records[i].cnic == cnic){ 
        return true;}
    }
    return false;
}

void CustomerManager::updateCustomerRecord(const string& cnic, const string& fullName,const string& gender, const string& phone,
const string& city, const string& password, int isBlocked) {
    vector<CustomerRecord> records = loadAll();
    for (int i = 0; i < records.size(); i++) {
        if (records[i].cnic == cnic) {
            if (!fullName.empty()){
            records[i].fullName = fullName;}
            if (!gender.empty()){ 
            records[i].gender = gender;
            }
            if (!phone.empty()){
            records[i].phone = phone;
            }
            if (!city.empty()){
            records[i].city = city;
            }
            if (!password.empty()){
            records[i].password = password;
            }
            records[i].isBlocked = isBlocked;
            break;
        }
    }
    saveAll(records);
}
