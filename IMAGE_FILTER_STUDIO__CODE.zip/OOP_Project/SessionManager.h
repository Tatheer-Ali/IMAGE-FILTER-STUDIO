#ifndef SESSIONMANAGER_H
#define SESSIONMANAGER_H

#include <string>
#include <vector>
using namespace std;

struct SessionRecord {
    string cnic;
    string timestamp;
    string filtersApplied;
    string outputFile;
};

class SessionManager {
private:
    static vector<SessionRecord> loadAll();
   
public:
    static void recordSession(const string& cnic, const string& timestamp,const string& filtersApplied, const string& outputFile);
    static void viewAllSessions();
    static void viewSessionsByCNIC(const string& cnic, const string& customerName);
    static int getSessionCount(const string& cnic);
   

};

#endif
