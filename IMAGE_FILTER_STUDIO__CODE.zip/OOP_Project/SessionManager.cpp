#include "SessionManager.h"
#include <fstream>
#include <iostream>
using namespace std;

void SessionManager::recordSession(const string& cnic, const string& timestamp, const string& filtersApplied, const string& outputFile){
    ofstream file("sessions.txt", ios::app);
    if (file) {
        file << cnic << "|" << timestamp << "|" << filtersApplied << "|" << outputFile << endl;
    }
}

vector<SessionRecord> SessionManager::loadAll() {
    vector<SessionRecord> sessions;
    ifstream file("sessions.txt");
    string line;
    while (getline(file, line)) {
        SessionRecord rec;
        int pos = 0, last = 0;
        // cnic
        while (line[pos] != '|' && line[pos] != '\0'){
        pos++;
        }
        rec.cnic = line.substr(last, pos - last);
        last = ++pos;
        // timestamp
        while (line[pos] != '|' && line[pos] != '\0'){
        pos++;
        }
        rec.timestamp = line.substr(last, pos - last);
        last = ++pos;
        // filtersApplied
        while (line[pos] != '|' && line[pos] != '\0'){
        pos++;
        }
        rec.filtersApplied = line.substr(last, pos - last);
        last = ++pos;
        // outputFile
        rec.outputFile = line.substr(last);
        sessions.push_back(rec);
    }
    return sessions;
}

void SessionManager::viewAllSessions() {
    vector<SessionRecord> sessions = loadAll();
    cout << endl << "All Sessions:" <<endl;
    cout << "CNIC           | Timestamp          | Filters                | Output File" << endl;
    cout << "-----------------------------------------------------------------------------" << endl;
    for (int i = 0; i < sessions.size(); i++) {
        const SessionRecord& s = sessions[i];
        cout << s.cnic << " | " << s.timestamp << " | " << s.filtersApplied;
        int spaces = 20 - s.filtersApplied.length();
        for (int sp = 0; sp < spaces; sp++) cout << " ";
        cout << " | " << s.outputFile << endl;
    }
}

void SessionManager::viewSessionsByCNIC(const string& cnic, const string& customerName) {
    vector<SessionRecord> sessions = loadAll();
    cout << endl << "Session history for " << customerName << ": " << cnic << endl;
    for (int i = 0; i < sessions.size(); i++) {
        if (sessions[i].cnic == cnic) {
            cout << sessions[i].timestamp << "|" << sessions[i].filtersApplied << "|" << sessions[i].outputFile <<endl;
        }
    }
}
//may be removed
int SessionManager::getSessionCount(const string& cnic) {
    vector<SessionRecord> sessions = loadAll();
    int count = 0;
    for (int i = 0; i < sessions.size(); i++) {
        if (sessions[i].cnic == cnic){ 
        ++count;
        }
    }
    return count;
}

