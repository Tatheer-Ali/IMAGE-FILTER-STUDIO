#ifndef CUSTOMERMANAGER_H
#define CUSTOMERMANAGER_H

#include "CustomerRecord.h"
#include <vector>
#include <string>
using namespace std;

class CustomerManager {
private:
    static vector<CustomerRecord> loadAll();
    static void saveAll(const vector<CustomerRecord>& records);
    static void addToBlocked(const string& cnic);
    static bool cnicExists(const string& cnic);
public:
    static bool registerCustomer(const string& cnic, const string& password,const string& fullName, const string& gender,const string& phone, const string& city);
    static bool loginCustomer(const string& cnic, const string& password, string& name, bool& isBlocked);
    static bool isBlocked(const string& cnic);
    static void viewAll();
    static void search(const string& term);
    static void blockCustomer(const string& cnic);
    static void deleteCustomer(const string& cnic);
    static string getCustomerName(const string& cnic);
    static void updateCustomerRecord(const string& cnic, const string& fullName,const string& gender, const string& phone,const string& city, const string& password, int isBlocked);

};

#endif
