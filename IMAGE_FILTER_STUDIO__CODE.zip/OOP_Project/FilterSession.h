#ifndef FILTERSESSION_H
#define FILTERSESSION_H

#include "Filter.h"
#include "Image.h"
#include <vector>
#include <string>
using namespace std;

class FilterSession {
private:
    vector<Filter*> filters;
    string timestamp;

public:
    FilterSession();
    ~FilterSession();

    FilterSession& addFilter(Filter* f);
    void applyAll(Image& img);

    int getFilterCount() const;
    string getFilterNames() const;
    string getPipelineString() const;
    string getTimestamp() const { return timestamp; }
};

#endif
