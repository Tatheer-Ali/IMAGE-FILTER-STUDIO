#ifndef USER_H
#define USER_H

#include <string>
using namespace std;

class User {
protected:
    string cnic;
    string fullName;

public:
    User(const string& cnic, const string& fullName);
    virtual ~User();

    virtual void showMenu() = 0;
    virtual string getRole() const = 0;

    string getCNIC() const;
    string getFullName() const; 
};

#endif
