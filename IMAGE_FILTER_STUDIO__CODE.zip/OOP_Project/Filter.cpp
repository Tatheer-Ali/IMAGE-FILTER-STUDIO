#include "Filter.h"

void GrayscaleFilter::apply(Image& img) {
    int w = img.getWidth(), h = img.getHeight();
    for (int r = 0; r < h; r++) {
        for (int c = 0; c < w; c++) {
            Pixel& p = img.at(r, c);
            int avg = (p.getR() + p.getG() + p.getB()) / 3;
            p.setR(avg); p.setG(avg); p.setB(avg);
        }
    }
}
string GrayscaleFilter::getName() const{ 
return "Grayscale"; 
}

void InvertFilter::apply(Image& img){
    int w = img.getWidth(), h = img.getHeight();
    for (int r = 0; r < h; r++) {
        for (int c = 0; c < w; c++) {
            Pixel& p = img.at(r, c);
            p.setR(255 - p.getR());
            p.setG(255 - p.getG());
            p.setB(255 - p.getB());
        }
    }
}
string InvertFilter::getName() const { 
return "Invert"; 
}

BrightnessFilter::BrightnessFilter(int delta):delta(delta){}
void BrightnessFilter::apply(Image& img) {
    int w = img.getWidth(), h = img.getHeight();
    for (int r = 0; r < h; r++) {
        for (int c = 0; c < w; c++) {
            Pixel& p = img.at(r, c);
            p.setR(p.getR() + delta);
            p.setG(p.getG() + delta);
            p.setB(p.getB() + delta);
        }
    }
}
string BrightnessFilter::getName() const {
   return "Brightness";
}

void ContrastFilter::apply(Image& img) {
    int w = img.getWidth(), h = img.getHeight();
    int minR = 255, maxR = 0, minG = 255, maxG = 0, minB = 255, maxB = 0;
    for (int r = 0; r < h; r++) {
        for (int c = 0; c < w; c++) {
            Pixel& p = img.at(r, c);
            int rv = p.getR(), gv = p.getG(), bv = p.getB();
            if(rv < minR) minR = rv;
            if(rv > maxR) maxR =rv;
            if (gv < minG) minG = gv;
            if(gv> maxG) maxG = gv;
            if (bv < minB) minB =bv;
            if(bv > maxB) maxB = bv;
        }
    }
    for (int r = 0; r < h; r++) {
        for (int c = 0; c < w; c++) {
            Pixel& p = img.at(r, c);
            if (maxR > minR) p.setR((p.getR() - minR) * 255 / (maxR - minR));
            if (maxG > minG) p.setG((p.getG() - minG) * 255 / (maxG - minG));
            if (maxB > minB) p.setB((p.getB() - minB) * 255 / (maxB - minB));
        }
    }
}
string ContrastFilter::getName() const {
return "ContrastStretch"; 
}

void RedFilter::apply(Image& img) {
    int w = img.getWidth(), h = img.getHeight();
    for (int r = 0; r < h; r++) {
        for (int c = 0; c < w; c++) {
            Pixel& p = img.at(r, c);
            p.setG(0); p.setB(0);
        }
    }
}
string RedFilter::getName() const { 
return "RedChannelOnly"; 
}

void GreenFilter::apply(Image& img) {
    int w = img.getWidth(), h = img.getHeight();
    for (int r = 0; r < h; r++) {
        for (int c = 0; c < w; c++) {
            Pixel& p = img.at(r, c);
            p.setR(0); p.setB(0);
        }
    }
}
string GreenFilter::getName() const { 
return "GreenChannelOnly"; 
}

void BlueFilter::apply(Image& img) {
    int w = img.getWidth(), h = img.getHeight();
    for (int r = 0; r < h; r++) {
        for (int c = 0; c < w; c++) {
            Pixel& p = img.at(r, c);
            p.setR(0); p.setG(0);
        }
    }
}
string BlueFilter::getName()const{ 
return "BlueChannelOnly"; 
}

void BoxBlurFilter::apply(Image& img) {
    Image copy = img;
    int w = img.getWidth(), h = img.getHeight();
    for (int r = 0; r < h; r++) {
        for (int c = 0; c < w; c++) {
            int sumR = 0, sumG = 0, sumB = 0, count = 0;
            for (int dr = -1; dr <= 1; dr++) {
                for (int dc = -1; dc <= 1; dc++) {
                    int nr = r + dr, nc = c + dc;
                    if (nr >= 0 && nr < h && nc >= 0 && nc < w) {
                        sumR += copy.at(nr, nc).getR();
                        sumG += copy.at(nr, nc).getG();
                        sumB += copy.at(nr, nc).getB();
                        ++count;
                    }
                }
            }
            img.at(r, c).setR(sumR / count);
            img.at(r, c).setG(sumG / count);
            img.at(r, c).setB(sumB / count);
        }
    }
}
string BoxBlurFilter::getName() const { 
return "BoxBlur"; 
}

void FlipHorizontalFilter::apply(Image& img) {
    int w = img.getWidth(), h = img.getHeight();
    for (int r = 0; r < h; ++r) {
        for (int c = 0; c < w / 2; ++c) {
            Pixel temp = img.at(r, c);
            img.at(r, c) = img.at(r, w - 1 - c);
            img.at(r, w - 1 - c) = temp;
        }
    }
}
string FlipHorizontalFilter::getName() const { 
return "FlipHorizontal"; 
}

void FlipVerticalFilter::apply(Image& img) {
    int w = img.getWidth(), h = img.getHeight();
    for (int c = 0; c < w; c++) {
        for (int r = 0; r < h / 2; r++) {
            Pixel temp = img.at(r, c);
            img.at(r, c) = img.at(h - 1 - r, c);
            img.at(h - 1 - r, c) = temp;
        }
    }
}
string FlipVerticalFilter::getName() const { 
return "FlipVertical"; 
}
