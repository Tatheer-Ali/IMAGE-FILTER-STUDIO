#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "User.h"
#include "Interfaces.h"
#include "Image.h"
#include "FilterSession.h"

class Customer : public User, public Serializable {
private:
    Image* currentImage;
    FilterSession* currentSession;

public:
    Customer();
    Customer(const string& cnic, const string& fullName);
    ~Customer();

    void showMenu();
    string getRole() const;
    void saveToFile();

    string getCNIC() const { 
    return cnic; 
    }
    string getName() const { 
    return fullName; 
    }

    void browseCatalog();
    void loadImage();
    void buildPipeline();
    void applyAndSave();
    void viewHistory();

};

#endif
