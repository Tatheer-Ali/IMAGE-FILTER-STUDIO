#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

#include "ImageFileManager.h"
#include <iostream>
using namespace std;

Image* ImageFileManager::loadImage(const string& filename) {
    int w, h, channels;
    unsigned char* data = stbi_load(filename.c_str(), &w, &h, &channels, 3);
    if (!data) {
        cout << "Failed to load image: " << filename << endl;
        
        return 0;
    }
    Image* img = new Image(w, h);
    for (int r = 0; r < h; r++) {
        for (int c = 0; c < w; c++) {
            int idx = 3 * (r * w + c);
            img->at(r, c) = Pixel(data[idx], data[idx+1], data[idx+2]);
        }
    }
    stbi_image_free(data);
    return img;
}

void ImageFileManager::saveImage(Image* img, const string& filename) {
    int w = img->getWidth(), h = img->getHeight();
    unsigned char* buf = new unsigned char[w * h * 3];
    for (int r = 0; r < h; r++) {
        for (int c = 0; c < w; c++) {
            int idx = 3 * (r * w + c);
            buf[idx] = img->at(r, c).getR();
            buf[idx+1] = img->at(r, c).getG();
            buf[idx+2] = img->at(r, c).getB();
        }
    }
    if (filename.size() > 4 && filename.substr(filename.size()-4) == ".png") {
        stbi_write_png(filename.c_str(), w, h, 3, buf, w * 3);
    } else {
        stbi_write_jpg(filename.c_str(), w, h, 3, buf, 90);
    }
    delete[] buf;
    cout << "Image saved to " << filename << endl;
}
