#include "FilterSession.h"
#include <iostream>
#include <ctime>
using namespace std;

static string getCurrentTimestamp() {
    time_t now = time(0);
    tm* t = localtime(&now);
    char buf[80];
   
    strftime(buf, sizeof(buf), "%a %b %e %H:%M:%S %Y", t);
    return string(buf);
}

FilterSession::FilterSession() : timestamp(getCurrentTimestamp()) {}

FilterSession::~FilterSession() {
    for (int i = 0; i < filters.size(); ++i){
        delete filters[i];
        }
    filters.clear();
}

FilterSession& FilterSession::addFilter(Filter* f) {
    filters.push_back(f);
    return *this;
}

void FilterSession::applyAll(Image& img) {
    int step = 1;
    for (int i = 0; i < (int)filters.size(); i++) {
        cout << "Applying filter " << step << "/" << filters.size() << ": " << filters[i]->getName() << " ..." << endl;
        filters[i]->apply(img);
        img.displayASCII();
        cout << endl;
        step++;
    }
}

int FilterSession::getFilterCount() const {
    return filters.size();
}

string FilterSession::getFilterNames() const {
    if (filters.empty()) 
    return "(empty)";
    string result;
    for (int i = 0; i < filters.size(); i++) {
        if (i != 0) result += " -> ";
        result += filters[i]->getName();
    }
    return result;
}

string FilterSession::getPipelineString() const {
    if (filters.empty()) return "none";
    string result;
    for (int i = 0; i < (int)filters.size(); i++) {
        string name = filters[i]->getName();
        if (name == "Grayscale") result += "Grayscale";
        else if (name == "Invert") result += "Invert";
        else if (name.find("Brightness") != string::npos) result += "BrightnessA";
        else if (name == "ContrastStretch") result += "ContrastStretch";
        else if (name == "RedChannelOnly") result += "RedChannelOnly";
        else if (name == "GreenChannelOnly") result += "GreenChannelOnly";
        else if (name == "BlueChannelOnly") result += "BlueChannelOnly";
        else if (name == "BoxBlur") result += "BoxBlur";
        else if (name == "FlipHorizontal") result += "FlipHorizontal";
        else if (name == "FlipVertical") result += "FlipVertical";
        else result += "?";
        if (i != (int)filters.size() - 1) result += ":->";
    }
    return result;
}
