#include "User.h"
#include <iostream>
using namespace std;

User::User(const string& cnic, const string& fullName):cnic(cnic),fullName(fullName){}

string User::getCNIC() const { 
    return cnic; 
    }
string User::getFullName() const { 
    return fullName; 
    }
User::~User() {}
