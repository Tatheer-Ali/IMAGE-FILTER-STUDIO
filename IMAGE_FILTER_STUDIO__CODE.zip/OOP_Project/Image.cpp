#include "Image.h"
#include "ImageFileManager.h"
#include <iostream>
using namespace std;

Image::Image(int w,int h):width(w), height(h){
   //DMA for grid image
    grid = new Pixel*[h];
    for (int i = 0; i < h; ++i){
        grid[i] = new Pixel[w];
    }
}

Image::Image(const Image& other) : width(other.width), height(other.height) { //copy constructor implementation
    
    grid = new Pixel*[other.height];
    for (int i=0;i<other.height;i++){
        grid[i]=new Pixel[other.width];
        for (int j=0;j<other.width;j++){
            grid[i][j]=other.grid[i][j];
        }
    }
}



Image::~Image() {
    
    for (int i =0;i<height;i++) 
      delete[] grid[i];
      delete[] grid;
      grid = 0;
}

int Image::getWidth()const{ 
return width; 
}
int Image::getHeight()const{ 
return height; 
}
Pixel& Image::at(int row, int col){
    return grid[row][col];
}



void Image::save(const string& filename){
    ImageFileManager::saveImage(this, filename);
}

void Image::displayASCII()const{

    int stepX=(width>72)?(width/72):1;
    int stepY=(height>30)?(height/30):1;
    for (int r=0;r<height;r+=stepY){
        for (int c=0;c<width;c+=stepX){
            cout<<grid[r][c];
        }
        cout<<endl;
    }
    cout << "Dimensions: " << width << "x" << height << endl;
}
