#include <iostream>
#include <string>
#include "Admin.h"
#include "Customer.h"
#include "CustomerManager.h"
#include "CatalogManager.h"
#include "Pixel.h"
#include "FilterSession.h"
using namespace std;


int main() {
    int choice;
    string cnic, password;
    int attempts;

    do {
        cout << endl <<" +---------------------------------------+";
        cout << endl <<"||         IMAGE FILTER STUDIO           ||";
        cout << endl <<" +---------------------------------------+";
        cout << endl <<"|| 1. Admin Login                        ||";
        cout << endl <<"|| 2. Customer Login                     ||";
        cout << endl <<"|| 3. New Customer? Register here        ||";
        cout << endl <<"|| 4. Exit                               ||";
        cout << endl <<"+----------------------------------------+";
        cout << endl <<"Enter choice: ";
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            
            string cnic, pwd;
            cout << "Admin CNIC: ";
            getline(cin, cnic);
            cout << "Password: ";
            getline(cin, pwd);
            if (Admin::checkCredentials(cnic, pwd)) {
                Admin admin;
                admin.showMenu();
            } else {
                cout << "Invalid admin credentials" << endl;
            }
        }
        else if (choice == 2) {
            attempts = 0;
            while (attempts < 3) {
                cout << "CNIC: ";
                getline(cin, cnic);
                cout << "Password: ";
                getline(cin, password);
                string name;
                bool isBlocked;
                if (CustomerManager::loginCustomer(cnic, password, name, isBlocked)) {
                    if (isBlocked) {
                        cout << "Account is blocked. Contact admin" << endl;
                        break;  // exit attempts loop, go back to main menu
                    }
                    Customer customer(cnic, name);
                    customer.showMenu();
                    break;  // exit attempts loop after successful login
                } else {
                    attempts++;
                    cout << "Invalid credentials. Attempts left: " << (3 - attempts) << endl;
                    if (attempts >= 3)
                        cout << "Too many failed attempts. Returning to main menu" << endl;
                }
            }
        }
        else if (choice == 3) {
            string cnic, pwd, confirmPwd, name, gender, phone, city;
            cout << "Enter CNIC (13 digits): ";
            getline(cin, cnic);
            if (cnic.length() != 13) {
                cout << "CNIC must be exactly 13 digits" << endl;
                continue;   // go back to main menu
            }
            bool valid = true;
            for (int i = 0; i < cnic.length(); ++i) {
                if (cnic[i] < '0' || cnic[i] > '9') { 
                valid = false; break;
                }
            }
            if (!valid) {
                cout << "CNIC must contain only digits" << endl;
                continue;
            }
            if (CustomerManager::isBlocked(cnic)) {
                cout << "This CNIC is blocked" << endl;
                continue;
            }
            cout << "Password (9 chars, 1 uppercase, 1 digit): ";
            getline(cin, pwd);
            cout << "Confirm password: ";
            getline(cin, confirmPwd);
            if (pwd != confirmPwd) {
                cout << "Passwords do not match" << endl;
                continue;
            }
            cout << "Full Name: ";
            getline(cin, name);
            cout << "Gender (M/F/Other): ";
            getline(cin, gender);
            cout << "Phone: ";
            getline(cin, phone);
            cout << "City: ";
            getline(cin, city);
            if (CustomerManager::registerCustomer(cnic, pwd, name, gender, phone, city)) {
                cout << "Registration successful!" << endl;
            } else {
                cout << "Registration failed" << endl;
            }
        }
        else if (choice == 4) {
            cout << "Goodbye!" << endl;
        }
        else {
            cout << "Invalid choice" << endl;
        }
    } while (choice != 4);

    return 0;
}
