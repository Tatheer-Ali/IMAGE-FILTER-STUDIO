#ifndef ADMIN_H
#define ADMIN_H

#include "User.h"

class Admin : public User {
private:
    static const string ADMIN_CNIC;
    static const string ADMIN_PASSWORD;
    void manageCatalog();
    void manageCustomers();
    void viewSessions();
public:
    Admin();
    ~Admin();

    void showMenu();
    string getRole() const;

    static bool checkCredentials(const string& cnic, const string& password);   
};

#endif
