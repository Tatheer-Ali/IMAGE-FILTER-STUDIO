#ifndef INTERFACES_H
#define INTERFACES_H

#include <string>
using namespace std;

class Saveable {
public:
    virtual void save(const string& filename) = 0;
    virtual ~Saveable() {}
};

class Serializable {
public:
    virtual void saveToFile() = 0;
    virtual ~Serializable() {}
};

#endif
