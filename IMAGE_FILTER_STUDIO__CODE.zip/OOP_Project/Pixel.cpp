#include "Pixel.h"

Pixel::Pixel() : r(0),g(0),b(0){} // Default Constructor for Pixel

Pixel::Pixel(int r, int g, int b): r(clamp(r)),g(clamp(g)),b(clamp(b)){}

int Pixel::getR()const{ 
return r; 
}
int Pixel::getG()const{ 
return g; 
}
int Pixel::getB()const{
return b; 
}

void Pixel::setR(int red){ 
r = clamp(red); 
}
void Pixel::setG(int green){ 
g = clamp(green); 
}
void Pixel::setB(int blue){ 
b = clamp(blue); 
}

int Pixel::clamp(int value){ //To keep the r.g.b value within 0-255
if(value<0){ 
return 0;
}
if(value> 255) 
return 255;
return value;
}

Pixel Pixel::operator+(const Pixel& other)const{ // + operator overloading to add two pixels
Pixel temp;
temp.r=clamp(r+other.r);
temp.b=clamp(b+other.b);
temp.g=clamp(g+other.g);
return temp;
}

char Pixel::getBrightnessChar()const{ // Function which map brightness value to a character 
int brightness=(r+g+b)/3;
if(brightness<32)
return ' ';
if(brightness <64){ 
return '.';
}
if(brightness< 96){ 
return ':';
}
if(brightness <128)
return '-';
    
if(brightness< 160){ 
return '=';
}
if(brightness <192){
    return '+';
}
if(brightness<224){ 
return '*';
}
if(brightness<240){ 
return '#';
}
return '@';
}

ostream& operator<<(ostream& os,const Pixel& p) { // to cout a pixel
os << p.getBrightnessChar();
return os;
}
