#ifndef PIXEL_H
#define PIXEL_H

#include <iostream>
using namespace std;

class Pixel {
private:
int r, g, b;

public:
Pixel(); //default constructor 
Pixel(int r,int g,int b); //parameterized constructor
int getR()const; // to get r 
int getG()const; // to get g
  
int getB()const; //to get b
void setR(int r);  // to set r
void setG(int g); //to set g
void setB(int b); // to set b

static int clamp(int value); // to keep the r,g,b value within the range 0-255

Pixel operator+(const Pixel& other) const; //operator overloading to add two pixel
char getBrightnessChar()const;   // top map brightness to a character

friend ostream& operator<<(ostream& os, const Pixel& p);   // operator overloading to print pixel
};

#endif
