#ifndef FILTER_H
#define FILTER_H
#include "Image.h"
#include <string>
using namespace std;

class Filter {
protected:
    Filter(){}
public:
    virtual void apply(Image& img) = 0; // pure virtual function to apply different filters
    virtual string getName() const = 0;
    virtual ~Filter() {}


};

class GrayscaleFilter : public Filter {
public:
    void apply(Image& img);
    string getName() const;
};

class InvertFilter : public Filter {
public:
    void apply(Image& img);
    string getName() const;
};

class BrightnessFilter : public Filter {
private:
    int delta;
public:
    BrightnessFilter(int delta);
    void apply(Image& img);
    string getName() const;
};

class ContrastFilter : public Filter {
public:
    void apply(Image& img);
    string getName() const;
};

class RedFilter : public Filter {
public:
    void apply(Image& img);
    string getName() const;
};

class GreenFilter : public Filter {
public:
    void apply(Image& img);
    string getName() const;
};

class BlueFilter : public Filter {
public:
    void apply(Image& img);
    string getName() const;
};

class BoxBlurFilter : public Filter {
public:
    void apply(Image& img);
    string getName() const;
};

class FlipHorizontalFilter : public Filter {
public:
    void apply(Image& img);
    string getName() const;
};

class FlipVerticalFilter : public Filter {
public:
    void apply(Image& img);
    string getName() const;
};

#endif
