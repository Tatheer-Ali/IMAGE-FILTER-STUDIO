#ifndef IMAGE_H
#define IMAGE_H

#include "Interfaces.h"
#include "Pixel.h"
#include <string>
using namespace std;

class FilterSession;

class Image : public Saveable {
private:
    Pixel** grid; // 2D array of pixels
    int width;
    int height;

public:
    Image(int width, int height); // default constructor used in image file manager, customer (generate test pattern), 
    Image(const Image& other); //copy constructor to be used Blur Box Filter 
  
    ~Image();

    int getWidth()const; // to get the width of image
    int getHeight()const; // to get the height of image
    Pixel& at(int row, int col); // used by all filter and to output the pattern of image
    

    void save(const string& filename); // to save the image
    void displayASCII()const; // to display the picture on terminal

   
};

#endif
