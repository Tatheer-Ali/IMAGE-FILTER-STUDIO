#ifndef FILTERINFO_H
#define FILTERINFO_H

#include <string>
using namespace std;

struct FilterInfo {
    int id;
    string name;
    string category;
    bool enabled;
};

#endif
