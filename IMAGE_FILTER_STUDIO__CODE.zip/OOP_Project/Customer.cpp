#include "Customer.h"
#include "CatalogManager.h"
#include "CustomerManager.h"
#include "SessionManager.h"
#include "ImageFileManager.h"
#include <iostream>
using namespace std;

Customer::Customer() : User("",""), currentImage(0), currentSession(0) {}

Customer::Customer(const string& cnic, const string& fullName):User(cnic,fullName),currentImage(0),currentSession(0){}

Customer::~Customer() {
  
    delete currentImage;
    delete currentSession;
}

void Customer::saveToFile() {
    CustomerManager::updateCustomerRecord(cnic, fullName, "", "", "", "", 0);
  }

void Customer::showMenu() {
    int choice;
    do {
        
        cout << endl <<"        Welcome, " << fullName ;
        cout << endl <<" +----------------------------------------+";
        cout << endl <<"|| 1. Browse Filter Catalog               ||";
        cout << endl <<"|| 2. Load Image                          ||";
        cout << endl <<"|| 3. Build Filter Pipeline               ||";
        cout << endl <<"|| 4. Apply Pipeline & Save Result        ||";
        cout << endl <<"|| 5. View My Session History             ||";
        cout << endl <<"|| 6. Logout                              ||";
        cout << endl <<" +----------------------------------------+";
        cout << endl <<"Enter choice: ";
        cin >> choice;
        cin.ignore();
        if (choice == 1 ){
          browseCatalog();
        }
        else if (choice == 2){
          loadImage();
        }
        else if (choice == 3){
        buildPipeline();
        }
        else if (choice == 4){
        applyAndSave();
        }
        else if (choice == 5){
        viewHistory();
        }
        else if (choice == 6){
        cout << "Logging out..." << endl;
        }
        else{
        cout << "INVALID CHOICE!!!" << endl;
        }
        
    } while (choice != 6);
}

string Customer::getRole() const { 
return "Customer"; 
}

void Customer::browseCatalog() {
    CatalogManager::viewCatalog();
}

void Customer::loadImage() {
    delete currentImage;
    currentImage = 0;
    string path;
    cout << "Enter image path: ";
    getline(cin, path);
    currentImage = ImageFileManager::loadImage(path);
    if (!currentImage) {
        cout << "Failed to load image" <<endl ;
    } else {
        cout << "Image loaded: " << currentImage->getWidth() << "x" << currentImage->getHeight() << endl;
        currentImage->displayASCII();
    }
}



void Customer::buildPipeline() {
    if (!currentImage) {
        cout << "No image loaded. Please load an image first" <<endl;
        return;
    }
    delete currentSession;
    currentSession = new FilterSession();
    vector<FilterInfo> enabled = CatalogManager::getEnabledFilters();
    if (enabled.empty()) {
        cout << "No filters enabled" << endl;
        return;
    }
    int id;
    do {
        cout << endl << "Current pipeline: " << currentSession->getFilterNames() << endl;
        cout << endl << "Available Enabled Filters:" << endl;
        for (int i = 0; i < enabled.size(); i++) {
            const FilterInfo& fi = enabled[i];
            cout << "  " << fi.id << ". " << fi.name << " [" << fi.category << "]" <<endl;
        }
        cout << "Enter filter ID to add (0 to finish): ";
        cin >> id;
        if (id == 0){ 
        break;
        }
        
        Filter* f = 0;
        if (id == 3) {   // Brightness filter (check your catalog.txt ID)
            int delta;
            cout << "Enter brightness adjustment value (-255 to 255, negative = darker, positive = brighter): ";
            cin >> delta;
            // Optional clamping to -255..255
            if (delta < -255) delta = -255;
            if (delta > 255) delta = 255;
            f = new BrightnessFilter(delta);
        } else {
            f = CatalogManager::createFilterById(id);
        }
        
        if (f) {
            currentSession->addFilter(f);
        } else {
            cout << "Invalid ID"<<endl;
        }
    } while (true);
    cout << "Pipeline built: " << currentSession->getFilterNames() << endl;
}

void Customer::applyAndSave() {
    if (!currentImage || !currentSession || currentSession->getFilterCount() == 0) {
        cout << "Please load an image and build a pipeline first "<<endl;
        return;
    }
    cout << "Applying pipeline..."<<endl;
    currentSession->applyAll(*currentImage);
   

    char saveChoice;
    cout << "Save result? (y/n): ";
    cin >> saveChoice;
    if (saveChoice == 'y' || saveChoice == 'Y') {
        string format;
        cout << "Save as (png/jpg): ";
        cin >> format;
        string filename = cnic + "_" + currentSession->getTimestamp() + "." + format;
        if (format == "png")
            currentImage->save(filename);
        else if (format == "jpg" || format == "jpeg")
            ImageFileManager::saveImage(currentImage, filename);
        else
            cout << "Unsupported format"<<endl;
        cout << "Image saved as " << filename << endl;
        SessionManager::recordSession(cnic, currentSession->getTimestamp(),currentSession->getPipelineString(), filename);
        saveToFile();
    }
}

void Customer::viewHistory() {
    SessionManager::viewSessionsByCNIC(cnic, fullName);
}
