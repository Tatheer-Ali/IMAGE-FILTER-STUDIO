#ifndef IMAGEFILEMANAGER_H
#define IMAGEFILEMANAGER_H

#include "Image.h"
#include <string>
using namespace std;

class ImageFileManager {
public:
    static Image* loadImage(const string& filename);
    static void saveImage(Image* img, const string& filename);
};

#endif
