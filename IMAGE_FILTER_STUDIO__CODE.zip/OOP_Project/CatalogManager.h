#ifndef CATALOGMANAGER_H
#define CATALOGMANAGER_H

#include "FilterInfo.h"
#include "Filter.h"
#include <vector>
#include <string>
using namespace std;

class CatalogManager {
public:
    static void createDefaultIfMissing();
    static vector<FilterInfo> loadCatalog();
    static void saveCatalog(const vector<FilterInfo>& catalog);
    static void viewCatalog();
    static void toggleFilter(int id);
    static vector<FilterInfo> getEnabledFilters();
    static Filter* createFilterById(int id);
};

#endif
