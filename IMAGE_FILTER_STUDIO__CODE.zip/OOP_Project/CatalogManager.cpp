#include "CatalogManager.h"
#include <fstream>
#include <iostream>
using namespace std;

void CatalogManager::createDefaultIfMissing() {
    ifstream file("catalog.txt");
    if (file.good()) return;
    ofstream out("catalog.txt");
    out << "1|Grayscale|Pixel Transform|1" << endl;
    out << "2|Invert|Pixel Transform|1" << endl;
    out << "3|BrightnessAdjust|Pixel Transform|1" << endl;
    out << "4|ContrastStretch|Pixel Transform|1" << endl;
    out << "5|RedChannel|Pixel Transform|1" << endl;
    out << "6|GreenChannel|Pixel Transform|1" << endl ;
    out << "7|BlueChannel|Pixel Transform|1" << endl;
    out << "8|BoxBlur|Spatial Filter|1" << endl;
    out << "9|FlipHorizontal|Geometric|1" << endl;
    out << "10|FlipVertical|Geometric|1" <<endl;
}

vector<FilterInfo> CatalogManager::loadCatalog() {
    createDefaultIfMissing();
    vector<FilterInfo> catalog;
    ifstream file("catalog.txt");
    string line;
    while (getline(file, line)) {
        FilterInfo fi;
        int pos = 0, last = 0;
        // id
        while (line[pos] != '|' && line[pos] != '\0') pos++;
        string idStr = line.substr(last, pos - last);
        fi.id = 0;
        for (int i = 0; i < idStr.length(); ++i) {
            fi.id = fi.id * 10 + (idStr[i] - '0');
        }
        last = ++pos;
        // name
        while (line[pos] != '|' && line[pos] != '\0') pos++;
        fi.name = line.substr(last, pos - last);
        last = ++pos;
        // category
        while (line[pos] != '|' && line[pos] != '\0') pos++;
        fi.category = line.substr(last, pos - last);
        last = ++pos;
        // enabled
        fi.enabled = (line[pos] == '1');
        catalog.push_back(fi);
    }
    return catalog;
}

void CatalogManager::saveCatalog(const vector<FilterInfo>& catalog) {
    ofstream file("catalog.txt");
    for ( int i = 0; i < catalog.size(); i++) {
        const FilterInfo& fi = catalog[i];
      
        file << fi.id << "|" << fi.name << "|" << fi.category << "|" << (fi.enabled ? "1" : "0") << endl;
    
    }
}

void CatalogManager::viewCatalog() {
    vector<FilterInfo> catalog = loadCatalog();
    cout << endl << "Filter Catalog: " << endl;
    cout << "ID  Name                Category        Enabled" << endl;
    cout << "-----------------------------------------------" << endl;
    for (int i = 0; i < catalog.size(); i++) {
        const FilterInfo& fi = catalog[i];
        cout << fi.id << "   "<< fi.name;
        int spaces = 20 - fi.name.length();
        for (int s = 0; s < spaces; s++){ 
        cout << " ";
        }
        cout << " " << fi.category;
        spaces = 15 - fi.category.length();
        for (int s = 0; s < spaces; s++){
 cout << " ";}
        cout << " " << (fi.enabled ? "Yes" : "No") << endl;
    
}}

void CatalogManager::toggleFilter(int id) {
    vector<FilterInfo> catalog = loadCatalog();
    for (int i = 0; i < catalog.size(); i++) {
        if (catalog[i].id == id) {
            catalog[i].enabled = !catalog[i].enabled;
            saveCatalog(catalog);
            cout << "Filter " << catalog[i].name << " is now " << (catalog[i].enabled ? "enabled" : "disabled") << endl;
            return;
        }
    }
    cout << "Filter ID not found" << endl;
}

vector<FilterInfo> CatalogManager::getEnabledFilters() {
    vector<FilterInfo> all = loadCatalog();
    vector<FilterInfo> enabled;
    for (int i = 0; i < all.size(); i++) {
        if (all[i].enabled) enabled.push_back(all[i]);
    }
    return enabled;
}

Filter* CatalogManager::createFilterById(int id) {
    if (id == 1) {
        return new GrayscaleFilter();
    } else if (id == 2) {
        return new InvertFilter();
    } else if (id == 3) {
        return new BrightnessFilter(0);
    } else if (id == 4) {
        return new ContrastFilter();
    } else if (id == 5) {
        return new RedFilter();
    } else if (id == 6) {
        return new GreenFilter();
    } else if (id == 7) {
        return new BlueFilter();
    } else if (id == 8) {
        return new BoxBlurFilter();
    } else if (id == 9) {
        return new FlipHorizontalFilter();
    } else if (id == 10) {
        return new FlipVerticalFilter();
    } else {
        return 0;
    }
}
